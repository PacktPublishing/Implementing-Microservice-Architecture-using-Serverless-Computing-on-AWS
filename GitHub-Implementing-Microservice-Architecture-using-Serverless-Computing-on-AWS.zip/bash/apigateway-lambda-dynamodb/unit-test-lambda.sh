(cd ../..;
python -m unittest discover test)