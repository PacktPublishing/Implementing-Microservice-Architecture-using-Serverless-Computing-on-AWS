#!/bin/sh
export profile="demo"
export region="eu-west-1"
export aws_account_id="000000000000"
export template="lambda-dynamo-data-api"
export bucket="testbucket121f"
export prefix="tmp/sam"